﻿//当前版本：V1.0.1
//CAP Login URL 
//1.【测试区】：https://dmzapts.auo.com/DMZ_CAP_EX/Login/Index  
//2.【正式区】：（1）阿里云：https://logon.auo.com.cn/login/index （2）AUHQ DMZ正式区：https://logon.auo.com/login/index 
const cap_Login_url = "http://captest2.corpnet.auo.com/CAP_EX/Login/Index";
//const cap_Login_url = "https://logon.auo.com/login/index";
//CAP API URL 
//1.【测试区】：http://captest2.corpnet.auo.com/CAP_EX_API/api/AuthFuncs  
//2.【正式区】：http://auhqpl01.corpnet.auo.com/CAP_API/api/AuthFuncs 
const cap_api_url = "http://captest2.corpnet.auo.com/CAP_EX_API/api/AuthFuncs";
//const cap_api_url = "http://auhqpl01.corpnet.auo.com/CAP_API/api/AuthFuncs";

//【1】获取User基础信息【调用该方法，获取User信息，通过返回值可确认是否通过CAP验证，若没有通过，则自动跳转至CAP登入页面】

function CAP_GetUserInfo(authToken) {
    var result = "";
    var cap_check_authToken = CAP_CheckAuthToken(authToken);
    if (cap_check_authToken) {
        $.ajax({
            type: "get",
            url: cap_api_url + "/GetUserInfoByToken",
            dataType: "json",
            async: false,
            data: { authToken: authToken },
            success: function (data) {
                if (data != null && data != '' && data.EmployeeId) {
                    result = data;
                }
                else {
                    //跳转CAP登入页面
                    window.location.href = CAP_ReturnUrl();
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                //alert("CAP GetUserInfoByToken Error," + textStatus + ": " + errorThrown);
            	alert("CAP GetUserInfoByToken Error," + textStatus + ": " + errorThrown);
            }
        });
    }
    else {
        //跳转CAP登入页面
        window.location.href = CAP_ReturnUrl();
    }
    return result;
}

//【2】检查权限
function CAP_CheckAuth(authToken, company, sysId, func) {
    var result = "";
    var cap_check_authToken = CAP_CheckAuthToken(authToken);
    if (cap_check_authToken) {
        $.ajax({
            type: "get",
            url: cap_api_url + "/CheckAuth",
            dataType: "json",
            data: { authToken: authToken, company: company, sysId: sysId, func: func },
            async: false,
            success: function (data) {
                result = data;
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
            	alert("CAP CheckAuth Error," + textStatus + ": " + errorThrown);
            }
        });
    }
    else {
        alert('AuthToken is null or empty');
    }
    return result;
}

//【3】根据功能获取User
function CAP_GetUserByFunc(authToken, company, sysId, funcs) {
    var result = "";
    var cap_check_authToken = CAP_CheckAuthToken(authToken);
    if (cap_check_authToken) {
        $.ajax({
            type: "post",
            url: cap_api_url + "/GetUserByFunc",
            dataType: "json",
            data: { AuthToken: authToken, company: company, sysId: sysId, Funcs: funcs },
            async: false,
            success: function (data) {
                result = data;
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert("CAP GetUserByFunc Error," + textStatus + ": " + errorThrown);
            }
        });
    }
    else {
        alert('AuthToken is null or empty');
    }
    return result;
}

//【4】获取角色列表
function CAP_GetRoleList(authToken, company, sysId) {
    var result = "";
    var cap_check_authToken = CAP_CheckAuthToken(authToken);
    if (cap_check_authToken) {
        $.ajax({
            type: "get",
            url: cap_api_url + "/GetRoleList",
            dataType: "json",
            data: { authToken: authToken, company: company, sysId: sysId },
            async: false,
            success: function (data) {
                result = data;
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert("CAP GetRoleList Error," + textStatus + ": " + errorThrown);
            }
        });
    }
    else {
        alert('AuthToken is null or empty');
    }
    return result;
}

//【5】根据User获取角色与功能列表
function CAP_GetRoleFuncList(authToken, company, sysId) {
    var result = "";
    var cap_check_authToken = CAP_CheckAuthToken(authToken);
    if (cap_check_authToken) {
        $.ajax({
            type: "get",
            url: cap_api_url + "/GetRoleFuncList",
            dataType: "json",
            data: { authToken: authToken, company: company, sysId: sysId },
            async: false,
            success: function (data) {
                result = data;
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert("CAP GetRoleFuncList Error," + textStatus + ": " + errorThrown);
            }
        });
    }
    else {
        alert('AuthToken is null or empty');
    }
    return result;
}

//【6】获取登入CAP完成后，浏览器URL中产生的CapAuthToken
function CAP_GetUrlAuthToken() {
    //URL中CapAuthToken参数名
    var name = "CapAuthToken";
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]); return null;
}

//检查取出的AuthToken是否有值
function CAP_CheckAuthToken(authToken) {
    var result = false;
    if (authToken == null || authToken == '' || authToken == undefined) {
        result = false;
    }
    else {
        result = true;
    }
    return result;
}

//获取CAP登入页面
function CAP_ReturnUrl() {
    //【测试区】
    //TestSiteAuthToken_URL=Y，因测试区无需注册，所以不知道哪些系统需要URL传递Token，加上这个参数，可在回调的URL中加入Token【只针对测试环境】
    return cap_Login_url + "?ReturnUrl=" + encodeURIComponent(window.location.href) + "&AppPath=" + encodeURIComponent(CAP_GetRootPath()) + "&TestSiteAuthToken_URL=Y";  //登入页面地址;
    //【正式区】
    return cap_Login_url + "?ReturnUrl=" + encodeURIComponent(window.location.href) + "&AppPath=" + encodeURIComponent(CAP_GetRootPath());  //登入页面地址;
}

//获取网站根路径(站点及虚拟目录)   
function CAP_GetRootPath() {
    var pathName = window.location.pathname.substring(1);
    var webName = pathName == '' ? '' : pathName.substring(0, pathName.indexOf('/'));
    //【注：有的系统没有webName，只需要截取到host即可，同样，注册时候也只需要注册到Host即可】
    //return window.location.protocol + '//' + window.location.host;
    return window.location.protocol + '//' + window.location.host + '/' + webName;
}

function CAP_ReturnLogin(){
	window.location.href = CAP_ReturnUrl();
}